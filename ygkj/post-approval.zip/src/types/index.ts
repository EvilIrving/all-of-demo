export interface EnvConfig {
  env: string;
  baseUrl?: string;
  baseApi?: string;
}
