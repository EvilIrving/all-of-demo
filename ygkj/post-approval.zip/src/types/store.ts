export interface RootStateTypes {
  [keys: string]: any;
}
